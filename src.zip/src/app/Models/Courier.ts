export class Courier {
    courierId:string;
    company:string;
    telephone:string;
    vehicleType:string;
    vehicleId:string;
}