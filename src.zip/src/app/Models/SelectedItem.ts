import { Product } from './Product';
export class SelectedItem {
    product:Product 
    qtyReq:number 
    added:boolean
}