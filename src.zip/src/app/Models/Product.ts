export class Product {
    productId:string
    productName:string
    productPrice:number
    qty:number
    reference:string
}